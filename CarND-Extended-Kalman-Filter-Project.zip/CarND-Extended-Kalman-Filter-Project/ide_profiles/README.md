See [Call for IDE Profiles Pull Requests](/README.md#Call%20for%20IDE%20Profiles%20Pull%20Requests)
in the root README for more information.